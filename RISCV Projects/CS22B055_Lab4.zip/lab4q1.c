#include<stdio.h>

int Roll;

int fav_n(){
    return 18;
}

void print( char *first_name[],char *last_name[],int fav_no){
    printf("First Name: %s",first_name);
    printf(", Last Name: %s",last_name);
    printf(", Roll : %d",Roll);
    printf(", favNo : %d",fav_n());
    printf("\n");
    
}
