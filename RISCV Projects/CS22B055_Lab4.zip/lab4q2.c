#include<stdio.h>
extern const char destination_string[50];

extern int concat( char source_string[],char append_string[] );

int main(){
    // char str1[] = "Hello ";
    // char str2[] = "IIT Madras !!!";

    int len = concat("Hello ","IIT Madras !!!");
    printf("concatinated string : %s",destination_string);
    printf(", Length = %d",len);
    printf("\n");
}