// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2710 Final Exam: 
// Date: 8 Nov, 2023, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.

#include<bits/stdc++.h>
using namespace std;
vector<int> v; 
//defined globaly for storing the inorder traversal

class Node{
    private:
        uint key;
        Node* left;
        Node* right;
        Node* parent;
        int height;
        int balancefactor;
    
    public:
    Node(){
      key = 0;
      left = right = parent = NULL;
      height = -1;
      
    }

    Node(int x){
        key = x;
        left = right = parent = NULL;
        height = -1;
    }

    friend class AVL;
};

class AVL{
    private:
        Node* root;

    public:

        void arrange(Node* E){

            // from this function Im getting the seg fault :(
            Node* temp= E;
            while(abs(bal(temp))<=1 && temp!=root){
                temp = temp->parent;
            }
            if(temp->left->left != NULL){
                Node* X =temp;
                Node* Y = temp->left;
                Node* Z = temp->left->left;

                if(X==root){
                     root = Y;
                     Y->right = X;
                     Y->left = Z;
                     X->parent = Y;
                     Z->parent = Y;
                     return;
                }
                
                Node* px = temp->parent;

                if(px->left == X){
                    px->left = Y;
                    Y->parent = px;
                    Y->right = X;
                    Y->left = Z;
                    X->parent = Y;
                    Z->parent = Y;
                }
                if(px->right == X){
                    px->right = Y;
                    Y->parent = px;
                    Y->right = X;
                    Y->left = Z;
                    X->parent = Y;
                    Z->parent = Y;
                    
                }
            }
            
            else if(temp->left->right!= NULL){
                Node* X = temp;
                Node* Y = temp->left;
                Node* Z = temp->left->right;

                if(X==root){
                     root = Z;
                     Z->right = X;
                     Z->left = Y;
                     X->parent = Z;
                     Y->parent = Z;
                     return;
                }
                Node* px = X->parent;

                if(px->left == X){
                    px->left = Z;
                    Z->parent = px;
                    Z->right = X;
                    Z->left = Y;
                    X->parent = Z;
                    Y->parent = Z;
                }
                if(px->right == X){
                    px->right = Z;
                    Z->parent = px;
                    Z->right = X;
                    Z->left = Y;
                    X->parent = Z;
                    Y->parent = Z;
                    
                }
            }

            

            else if(temp->right->left!= NULL){
                Node* X =temp;
                Node* Y = temp->right;
                Node* Z = temp->right->left;
                

                if(X==root){
                     root = Z;
                     Z->right = Y;
                     Z->left = X;
                     X->parent = Z;
                     Y->parent = Z;
                     return;
                }
                Node* px = temp->parent;

                if(px->left == X){
                    px->left = Z;
                    Z->parent = px;
                    Z->left = X;
                    Z->right = Y;
                    X->parent = Z;
                    Y->parent = Z;
                }
                if(px->right == X){
                    px->right = Z;
                    Z->parent = px;
                    Z->left = X;
                    Z->right = Y;
                    X->parent = Z;
                    Y->parent = Z;
                    
                }
            }

            else if(temp->right->right!= NULL){
                Node* X =temp;
                Node* Y = temp->right;
                Node* Z = temp->right->right;
                
                if(X==root){
                     root = Y;
                     Y->right = Z;
                     Y->left = X;
                     X->parent = Y;
                     Z->parent = Y;
                     return;
                }

                Node* px = temp->parent;

                if(px->left == X){
                    px->left = Y;
                    Y->parent = px;
                    Y->left = X;
                    Y->right = Z;
                    X->parent = Y;
                    Z->parent = Y;
                }
                if(px->right == X){
                    px->right = Y;
                    Y->parent = px;
                    Y->left = X;
                    Y->right = Z;
                    X->parent = Y;
                    Z->parent = Y;
                    
                }
            }

            

        }
        
        int ht_ls(Node* E){ // hieght for left subtree
            int hls = 0;
            if(E->left==NULL ) return 0;

            Node* temp = E->left;
            hls++;
            if(temp->left == NULL && temp->right != NULL){
                temp= temp->right;
                hls++;
                if(temp->left != NULL && temp->right != NULL) ht_ls(temp);
                
            }
            if(temp->left != NULL && temp->right ==NULL){
                temp = temp->left;
                hls++;
                if(temp->left != NULL && temp->right != NULL) ht_ls(temp);
                
            }

            return hls;
        }

        int ht_rs(Node* E){ // hieght for right subtree
            int hrs = 0;
            if(E->right==NULL ) return 0;

            Node* temp = E->right;
            hrs++;
            if(temp->left == NULL && temp->right != NULL){
                temp= temp->right;
                hrs++;
                if(temp->left != NULL && temp->right != NULL) ht_ls(temp);
                
            }
            if(temp->left != NULL && temp->right ==NULL){
                temp = temp->left;
                hrs++;
                if(temp->left != NULL && temp->right != NULL) ht_ls(temp);
                
            }

            return hrs;
        }



        int bal(Node* E){ // balance factor calcualting seperately but im not able to debug tht it si working or not 
            return ht_ls(E) - ht_rs(E);
        }

        void insert(int x){
            Node* NewNode = new Node(x);
            inserthelp(NewNode);
        }
        
        
        void inserthelp(Node* E){
            // Node* NewNode = new Node(x);
            if(root == NULL){
                root = E;
                return;
            }
            Node* temp = root;
            while(temp->right != NULL && temp->left != NULL){
                if(E->key > temp->key && temp->right!= NULL) temp = temp->right;

                if(E->key < temp->key && temp->left!= NULL) temp = temp->left;
            }

            if(temp->key < E->key && temp->left == NULL){
                temp->left = E;
                if(temp->left->left != NULL ||
                   temp->left->right!=NULL ||
                   temp->right->left!= NULL ||
                   temp->right->right) arrange(E);
                
            }
            if(temp->key > E->key && temp->right == NULL){
                temp->right = E;
                if(temp->left->left != NULL ||
                   temp->left->right!=NULL ||
                   temp->right->left!= NULL ||
                   temp->right->right) arrange(E);
            }


        }

        void inorder(){
            inorderhelp(root);
        }
        void inorderhelp(Node* E){
            
            inorderhelp(E->left);
            v.push_back(E->key);
            inorderhelp(E->right);
        }

        Node* inorder_search_help(Node* E,int k){
            
            inorderhelp(E->left);
            if(E->key == k) return E;
            inorderhelp(E->right);

            return NULL;
        }

        Node* Search(int x){
            return inorder_search_help(root,x);
        }

        void printbal(int m,int n){
            if(Search(m) != NULL) cout<<bal(Search(m))<<" ";
            else cout<<-10<<" ";

            if(Search(n)!= NULL) cout<<bal(Search(n))<<endl;
            else cout<<-100<<endl;

        }
        void printLR(Node* E){
            if(E->left != NULL)cout<<E->left->key<<" ";
            else cout<<-1<<" ";

            if(E->right != NULL) cout<<E->right->key<<endl;
            else cout<<-1<<endl;
        }



        
};


int main(){
    AVL Tree;
    int N;
    cin>>N;

    for(int i=0;i<N;i++){
          int x;
          cin>>x;
          Tree.insert(x);
          //while entering the 2nd Input-> gettign Seg fault
          //I dry run the test and still not able to figure out the following code
    }

    int i,j;
    cout<<v[i-1]<<" "<<v[j-1]<<endl;

    int m,n;
    cin>>m>>n;

    Tree.printbal(m,n);

    int p;
    cin>>p;

    if(Tree.Search(p)!= NULL) Tree.printLR(Tree.Search(p));
    else cout<<-100<<endl;

}