// NEERAJ BANDHEY
//CS22B055
//Sir pls give scores I had putted effort pls don,t put 0



#include<bits/stdc++.h>
using namespace std;
#define long long int

class node{
    public:

    int Account_NO;
    int Accnt_balance;
    node* next;

    node(int val){
        Account_NO = val;
        Accnt_balance = 1000; 
        next = NULL;
    }
};

class SLL{
   public:
   int len;
   node* first;
   node* last;

   SLL(){
    first = NULL;
    last = nullptr;
   }

   public:

   void push_accnt(int acnt){
       node* temp = new node();
       temp->Account_NO = acnt;
       temp->Accnt_balance =1000;
       len++;
   }

//     void push_SLL(int val){
      
//       node* temp = new node(val);
//       if(first == nullptr && last == nullptr){
//         first = temp;
//         last = temp;
//         temp->next = nullptr;
//         return;
//       }
//       last->next = temp;
//       last = temp;
//    }
};

class dnode{
    public:
    dnode* next;
    dnode* prev; 
    int accnt;
    char s;
    int paise;
    bool process = false;
    int i=0;

    dnode(){
        next= nullptr;
        prev = nullptr;
    }

    dnode(int given_account, char y, int mny){
        accnt = given_account;
        s = y;
        paise = mny;
    }

    friend class DLL;
};

class DLL{
    public:

    dnode* head;
    dnode* tail;
    dnode* cursor;
    int len;
    
    public:
    DLL(){
        head = new dnode();
        tail = new dnode();

        head->next = tail;
        tail->prev = head;

        tail->prev = head;
        tail->next = NULL;
        cursor = head;
        len = 0;
    }

     void push_trans(int x,char st,int trans){


       dnode* temp = new dnode();
       temp->next = NULL;
       temp->prev = NULL;
       temp->accnt = x;
       temp->s = st;
       temp->paise = trans;

       tail->prev->next = temp;
       temp->prev = tail->prev;
       temp->next = tail;
       tail->prev = temp;
       
       
   }


    
    void F(int x){
        node* temp = head;
       for(int j=0;j<x;j++){
        cursor = cursor->next;
        i++;

         while(temp!=NULL){
             if(temp->Account_NO == cursor->accnt){
                if(s=='W') temp->Accnt_balance -= cursor->paise;
                else{
                    temp->Accnt_balance += cursor->paise;
                }   
                cursor->process = true;
                break;

             }
         }
         if(cursor->next == tail){
               return;
           }
        }
   

    }

     void R(int y){  while(cursor!=tail){
          
       }
       node * temp = first;
       while(y--){
           cursor = cursor->prev;
           i--;
           if(cursor->s == 'W'){
              temp->account_blanace -= cursor->paise;
              cursor->prcs = true; 
              
           }
           else if(cursor->s == 'D'){
            temp->account_blanace += cursor->paise;
            cursor->prcs = true;
           }

           if(cursor ->prev == nullptr){return;}
        }
     }

     void add_after(dnode* addafter, dnode* toadd){
        toadd->next = addafter->next;
        node* tem = addafter->next;
        addafter->next = todd;
        toadd->prev = addafter;
        tem->prev = toadd;

        
     }

     void ITK(){
       int num;
       char s;
       int money;

       int k;
       cin>>num>>s>>money;
       cin>>k;
       if(k>len || k<1) return;

       dnode * temp = head;
       for(int i=0;i<k;i++){
        temp = temp->next;
       }

       dnode* new_tran = new dnode();
       new_tran->accnt = num;
       new_tran->s = s;
       new_tran->paise = money;

       if(k>=i){
          add_after(temp,new_tran);
       }
       if(k<i){
         add_after(temp,new_tran);
         new_tran->process = true;
         
         node* temp1 = head;

         while(temp!=NULL){
             if(temp->Account_NO == num){
                if(s=='W') temp->Accnt_balance -= money;
                else{
                    temp->Accnt_balance += money;
                }

             }
         }
        }
     }

    void DAM(int m,int acnt){

        dnode* temp= cursor;
        
       if(m>0){
        temp = temp->next;
           while(m>0){
               if(temp->accnt== acnt){
                   m--;
                   node* temp1 = temp;
                   temp = temp->next;
                   i++;
                   delete(temp1);
                  
               }
           }
          
       }
       else{    
          while(m<0){
           if(temp->accnt == acnt){
               m++;
               node* temp1 = temp;
               temp = temp->prev;
               delete(temp1);
              
           }
          }
       }
   }

    void C(int n){
     F(n);
   }

    void S(int A){
      dnode* temp = head;
     while(temp->next != cursor){
        if(temp->accnt == A && temp->process == true){
            cout<<temp->accnt<<" "<<temp->s<<" "<<temp->paise;
            cout<<endl;
        }
     }
    }

     void G(int x){
       node* temp = first;
       int cnt = 0;
       while(temp != NULL){
           if(temp->Accnt_balance >=x) cnt++;
           temp= temp->next;
       }
       cout<<cnt<<endl;
   }

   void M(){
       node* temp = first;
       int maxa = INT_MIN;
       while(temp->next != NULL){
           maxa = max(temp->Accnt_balance,maxa);
       }
       node* temp1 = head;
       while(temp1->Accnt_balance == maxa){
           cout<<temp1->Account_NO<<" ";
       }
       cout<<endl;
   }

   void V(int x){
       node* temp = first;
       while(temp->next != NULL){
           if(temp->Account_NO == x){
               cout<<temp->Accnt_balance;
               cout<<endl;
               return;
           }
       }
   }
     };


   signed main(){
    SLL list;
    DLL Dlist;
        int n;
        cin>>n;

        for(int i=0;i<n;i++){
            int x;
            cin>>x;
            list.push_accnt(x);
        }

        int m;
        cin>>m;
        for(int i=0;i<m;i++){
            int accnt;
            char s;
            int mny;

            cin>>accnt>>s>>mny;
            Dlist.push_trans(accnt,s,mny);
        }

    string str;
   cin>>str;


   if(str == "F"){
       int x;
       cin>>x;
       Dlist.F(x);
   }
    else if(str == " R"){
       int y;
        cin>>y;
       Dlist.R(y);
   }
   else if(str == "I"){
    Dlist.ITK();
   }
   else if(str == "D"){
    int acnt;
    cin>>acnt;
    int m;
    cin>>m;
    Dlist.DAM(m,acnt);
   }
   
   else if(str=="C"){
    Dlist.C(m);
   }
   else if(str == "S"){
    int y;
    cin>>y;
    Dlist.S(y);
   }

   else if(str == "G"){
    int x;
    cin>>x;
    Dlist.G(x);

   }
   else if(str == "M"){
    Dlist.M();
   }

   else if(str == "V"){
    int x;
    cin>>x;
    Dlist.V(x);
   }


}

        
















    








   

 



    



