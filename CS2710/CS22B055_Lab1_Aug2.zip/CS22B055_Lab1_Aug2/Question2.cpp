#include<bits/stdc++.h>
using namespace std;

int main(){
    int n;
    cin>>n;

    if(n==0){
        cout<<0<<endl;
    }
    else{

    vector<int> arr(n);
    int k[n];
    for(int i=0; i<n; i++){
        cin>>arr[i];
        k[i]=arr[i];
    }

    sort(arr.begin(),arr.end());

    int p = arr[n-1];

    for(int i = 0 ;i < n;i++){
        if(k[i]==p){
            cout<<i<<endl;
            break;
        }
    }
    }
    
     

    

}