// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2710 Lab Number: 10
// Date:25 Oct, 2023, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.

#include <iostream>
#include <queue>
#include <stack>
#include <vector>
#include <string>
#include <cassert>
#include <cstdlib>

using namespace std;
inline void printb(string mesg)
{cout << "*****" << mesg << endl;}

class Node {

private:
  
  string data;
  // Update
  Node *next;

public:
  Node(string s){
    data = s;
    next = NULL;
  }

  friend class SLLv4;
  friend class GraphList;
  friend ostream& operator<<(ostream& os, const Node& E);
};

// Update this
// ostream& operator<<(ostream& os, const Node& E)
// {
//   os << "(" << E.vertex << ", " << E.edge_weight << ")";
//   return os;
// }


class SLLv4 {

private:

  Node *first;
  int len;

public:
  
  SLLv4()
  {
    first = nullptr;
    len = 0;
  }

  void insertNode(Node *add)
  {
    Node *temp;
    
    if (first == nullptr)
      {
	first = add;
	len++;
	return;
      }

    temp = first;

    while (temp -> next != nullptr) temp = temp->next;

    temp->next = add;
    len++;
  }

  void remove(Node* del){
    Node* temp = first;
    while(temp->next != del){
        temp =temp->next;
    }
   Node* temp2 = temp->next;
   temp->next = temp2->next;
   temp2->next = NULL;

   delete temp2;
}

Node* Locate(string s){
   Node* temp = first;
   while(temp!=NULL){
    if(temp->data == s){
        return temp;
    }
    temp =temp->next;
   }
   return NULL;
}

  friend class GraphList;
  
};

class GraphList {

private:
  int N; // Number of vertices
  vector<SLLv4 *>  AdjList;
  vector<string> V; 	
  // Each pointer points to a singly linked list.
  // Regular SLL, no head node.
  vector<bool> marked;
  
public:

  GraphList(int size)
  {
    N = size;

    AdjList.resize(N);
    for (int i = 0; i < N; i++)
      AdjList[i] = new SLLv4();	

    marked.resize(N);
  }

  

  Node* getNode(string s){
     for(int i=0;i<N;i++){
        if(AdjList[i]->first->data == s){
            return AdjList[i]->first;
        }
     }
  }
  
  int getindex(string s){
    for(int i=0;i<N;i++){
       if(AdjList[i]->first->data == s){
        return i;
       }
    }
    return -1;
  }

  void clear_marked()
  {
    for (int i = 0; i < N ; i++)
      marked[i] = false;
  }

  void PrintGraph()
  {
    for (int i = 0; i < N; i++)
      {
	cout << "   " << i << "   |";
	Node *temp = AdjList[i]->first;

	while (temp != nullptr)
	  {
	    cout << *temp << "  ";
	    temp = temp->next;
	  }
	cout << endl;
      }
  }

  bool check_edge(string A, string B){
    int t1;
    int t2;
    for(int i=0;i<N;i++){
        if(AdjList[i]->first->data == A){
            t1 = i;
        }
        if(AdjList[i]->first->data == B){
            t2 = i;
        }
    }
    
    for(int j=0; j<AdjList[t1]->len; j++){
        if(AdjList[j]->first->data == B) return true;
    }
    return false;
  }

  void AddEdge(string A,string B){
    Node* temp;
    if(check_edge(A,B)){

    }
    else{
     Node* temp1 = new Node(B);
     Node* temp2 = new Node(A);
     int t1;
     int t2;

      for(int i=0;i<N;i++){
        if(AdjList[i]->first->data == A){
            t1 = i;
        }
        if(AdjList[i]->first->data == B){
            t2 = i;
        }
    }

    AdjList[t2]->insertNode(temp1);
    AdjList[t2]->insertNode(temp2);
    
    }
  }

  void DeleteEdge(string A, string B){
    if(check_edge(A,B)){
        int t1,t2;
       for(int i=0;i<N;i++){
        if(AdjList[i]->first->data == A){
            t1 = i;
        }
        if(AdjList[i]->first->data == B){
            t2 = i;
        }
    }

        AdjList[t1]->remove(AdjList[t1]->Locate(B));
        AdjList[t2]->remove(AdjList[t2]->Locate(A));

    }
  }
  vector<string> DFS_alternate(string A){
    int x = getindex(A);
    vector<string> v;
    v.push_back(A);
    //cout << "*** Starting DFS from node: " << A << " ****" << endl;
    DFSHelp(x,v);
    //cout << "*** Ending DFS from node: " << A << " ****" << endl;

    return v;
  }

  vector<string>  DFS(string A)
  {
    int x = getindex(A);
    clear_marked();
    vector<string> v;
    v.push_back(A);
    //cout << "*** Starting DFS from node: " << A << " ****" << endl;
    DFSHelp(x,v);
    //cout << "*** Ending DFS from node: " << A << " ****" << endl;

    return v;

  }

  void DFSHelp(int i,vector<string> &v)
  {
    marked[i] = true;
    cout << i << "  " << endl;

    Node *temp = AdjList[i]->first; // Neighbor List of i.
    
    if (temp != nullptr)	// temp is nullptr if i has no neighbors
      {				
	string n;
	// Traverse all neighbors of node i using its SLL
	for (int k = 0; k < AdjList[i]->len; k++)
	  {
	    n = temp->data;
        int y = getindex(temp->data);
	    if (marked[y] == false)
	      {
            v.push_back(n);
		// cout << "DFSHelp on: " << n << " from: " << i << endl;
		DFSHelp(y,v);
	      }
	    temp = temp->next;
	  }
      }
  }
  int CC(){
    int cnt = 0;
    vector<string> vec;
    clear_marked();
    for(int i=0;i<N;i++){
        vec = DFS_alternate(AdjList[i]->first->data);
        if(vec.size()>0)cnt++;
    }

    return cnt;
    
  }

  vector<string> BFS(string s)
  {  int x = getindex(s);
    clear_marked();
    vector<string> v;
    v.push_back(s);
    //cout << "*** Starting DFS from node: " << A << " ****" << endl;
    BFSHelp(x);
    //cout << "*** Ending DFS from node: " << A << " ****" << endl;

    return v;
  }

  void BFSHelp(int i){
    queue<int> q;
    marked[i] = true;
    q.push(i);

    while(!q.empty()){
        int s = q.front();
        q.pop();

        Node* temp = AdjList[i]->first;
        while(temp!= NULL){
            string s = temp->data;
            if(!marked[getindex(s)]){
                q.push(getindex(s));
                marked[getindex(s)] = true;

            }
            temp = temp->next;
        }
    }
    }

  bool PathExist(string A,string B){
      vector<string> v;
      v = BFS(A);
      for(int i=0;i<v.size();i++){
        if(v[i] == B){
            return true;
        }
      }
      return false;
  }
};


int main()
{
int n;
cin>>n;
GraphList G(n);


for(int i=0;i<n;i++){
    string k;
    cin>>k;
}

int t;
cin>>t;
for(int i=0;i<t;i++){
    string s1,s2;
    cin>>s1>>s2;
    G.AddEdge(s1,s2);
}

int q;
cin>>q;

while(q--){
    string s;

    if(s=="I"){
        string x,y;
        cin>>x>>y;
        G.AddEdge(x,y);
    }

    else if(s=="D"){
        string x,y;
        cin>>x>>y;
        G.DeleteEdge(x,y);
    }
    else if(s=="C"){
        cout<<G.CC()<<endl;
    }
    else if(s=="R"){
        string x,y;
        cin>>x>>y;
        cout<<G.PathExist(x,y)<<endl;
    }
}


  
}