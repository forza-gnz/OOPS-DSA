// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2710 Midterm Exam
// Date: Sep. 20, 2023, 2pm
// Question No. 2
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty during the exam will result in
// corrective action imposed by the IIT Madras Senate.

#include<bits/stdc++.h>
using namespace std;

class Elem{
    private:
    string myword;
    Elem* next;
    Elem* prev;

    public:
    Elem(){
        myword = "";
        next =NULL;
        prev =NULL;
    }
    void printElem(){
        cout<<myword<<endl;
    }

    friend class Sentence;
};

class Sentence{
    private:
    Elem* head;
    Elem* tail;
    int len;

    public:
    Sentence(){
        len = 0;
        head = tail =NULL;
    }

    bool isempty(){
        if(head==NULL && tail == NULL){
            return true;
        }
        else return false;
    }

    int length(){
        return len;
    }

    Elem *Locate(string s){
        Elem *temp = head;
        while(temp->next != NULL){
            temp = temp->next;
            if(temp->myword == s){
                return temp;
            }
        }
        return NULL;
    }

    void EnqLast(string s){
        len++;
        Elem* temp = new Elem();
        temp->myword = s;
        temp->next = NULL;
        temp->prev = NULL;

        if(isempty()){
            head = temp;
            tail = temp;
        }
        else{
        tail->next = temp;
        temp->prev = tail;
        
        tail = temp;
        } 
    }

    void EnqAfter(Elem* loc , string s){
        len++;
        Elem* temp = new Elem();
        temp->myword = s;
        

        Elem* temp1 = loc->next;

        loc->next = temp;
        temp->prev = loc;
        temp1->prev = temp;
        temp->next =temp1;
    }

    void DeqFirst(){
        if(len == 1){
            delete head;
            len--;
        }

        else if(len==0){}

        else{
            Elem* temp = head;
            head = head->next;
            head->prev = NULL;

            delete temp;
            len--;
        }
        
    }

    void DeqLast(){
        if(len == 1){
            delete head;
            len--;
        }

        else if(len==0){}

        else{
            Elem* temp = tail;
           tail = temp->prev;
           tail->next = NULL;

           delete temp;
           len--;
        }
        
    }

    void revPrint(){
        Elem* temp = tail;
        while(temp != head){
            cout<<temp->myword<<" ";
            temp = temp->prev;
        }
        cout<<temp->myword;
        cout<<endl;
    }
};

int main(){
    int n;
    cin>>n;
    Sentence S;

    for(int i=0 ; i < n ; i++){
        string s;
        cin>>s;
        S.EnqLast(s);
    }

    int q;
    cin>>q;

    while(q--){
        char c;
        cin>>c;

        if(c=='I'){
            string a,g;
            cin>>a>>g;
            Elem* temp = S.Locate(a);
            S.EnqAfter(temp,g);
        }
        else if(c=='F'){
            if(!S.isempty()){
                S.DeqFirst();
            }
        }
        else if(c=='L'){
            if(!S.isempty()){
                S.DeqLast();
            }
        }
        else if(c=='A'){
            if(!S.isempty()){
                S.revPrint();
            }
        }
        else if(c=='W'){
            if(S.isempty()){
                cout<<0<<endl;
            }
            else{
                cout<<S.length()<<endl;
            }
        }
    } 
   
}