// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2710 Midterm Exam
// Date: Sep. 20, 2023, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty during the exam will result in
// corrective action imposed by the IIT Madras Senate.

#include<bits/stdc++.h>
using namespace std;

int main(){
    int t;
    cin>>t;
    string error = "-271020092023";
    while(t--){
        bool check = true;
        stack<int> st;
        int n;
        cin>>n;

        for(int i=0;i<n;i++){
            string s;
            cin>>s;
            
            if(s=="*" || s=="+" || s=="-" || s=="/" || s=="%"){
            if(s=="*"){

                if(st.size()>=2){
                int x= st.top();
                st.pop();
                int y = st.top();
                st.pop();

                st.push(x*y);
                }
                else{
                    check = false;
                    break;
                }
                
            }
            if(s=="+"){
                if(st.size()>=2){
                int x= st.top();
                st.pop();
                int y = st.top();
                st.pop();
                st.push(x+y);
                }
                 else{
                    check = false;
                    break;
                }
               
                
            }
            if(s=="-"){
                if(st.size()>=2){
                int x= st.top();
                st.pop();
                int y = st.top();
                st.pop();

                st.push(y-x);
                }
                 else{
                    check = false;
                    break;
                }

            }
            if(s=="/"){
                if(st.size()>=2){
                int x= st.top();
                st.pop();
                int y = st.top();
                st.pop();

                st.push(y/x);
                }
                 else{
                    check = false;
                    break;
                }
               

            }
             if(s=="%"){
                if(st.size()>=2){
                int x= st.top();
                st.pop();
                int y = st.top();
                st.pop();

                st.push(y%x);
                }
                 else{
                    check = false;
                    break;
                }

            }
            }
            else{
            st.push(stoi(s));
            }
            
            
        }

        if(check && st.size()==1){
            cout<<st.top()<<endl;
        }
        else{
            cout<<error<<endl;
        }

        

    }
}
