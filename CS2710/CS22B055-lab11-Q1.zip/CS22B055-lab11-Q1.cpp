
// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2710 Lab Number: 11
// Date: 1st Nov, 2023, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.

#include<iostream>
#include<vector>
#include<string>
using namespace std;

enum status {ACTIVE, DELETED, EMPTY};

long int HashFn1(string s, long int M)
{ int sum = 0;
    for(int i=0; i<s.length() ;i++){
        sum += int(s[i]);
    }
  //  return (x^2 + 3*x) % M;
  return sum % M;
}

long int HashFn2(string s, long int R)
{
    int sum = 0;
    for(int i=0; i < s.length() ;i++){
        sum += int(s[i]);
    }
  return (R - (sum % R));
}

// Warning: Does not correctly check if x is present in table
// Duplicate addition of x to Table is possible
// Ideally, Search for x and if not found, then insert x.

void HT_insert(vector<string> &HashTable1,vector<string> &HashTable2,
	    vector<status> &StatusTable1, vector<status> &StatusTable2,
	    string x, long int M,int R) 
{
  long int pos, newpos1, newpos2;
  int i,j;

  pos = HashFn1(x, M);
  i = 0;
  j = 0;
  
  while (i < M)
    { //cout<<i<<" ";
      //      newpos = (pos + i) % M;
      newpos1 = (pos + i*i) % M;  // Quadratic
      //      newpos2 = (pos + i* HashFn2(x,R)) % M; 


      if (StatusTable1[newpos1] != ACTIVE)
	{
	  //	  probecount += (i+1);
	  HashTable1[newpos1] = x;
	  StatusTable1[newpos1] = ACTIVE;
	  cout<<newpos1<<" ";

	  break;
	}
      else
	{
	  i++;
	  //cout << "i: " << i << endl;
	}
    
    }

  if (i == M)
    { cout<<-1<<" ";
    }

  while (j < M)
    { //cout<<j<<" ";
      //      newpos = (pos + i) % M;
      //      newpos1 = (pos + i*i) % M;  // Quadratic
      newpos2 = (pos + j* HashFn2(x,R)) % M; 

     

      if (StatusTable2[newpos2] != ACTIVE)
	{
	  //	  probecount += (i+1);
	  HashTable2[newpos2] = x;
	  StatusTable2[newpos2] = ACTIVE;
	  cout<<newpos2<<endl;

	  break;
	}
      else
	{
	  j++;
	  //cout << "i: " << j << endl;
	}
    }

    if (j == M)
    { cout<<-1<<endl;
    }   
      
}

void HT_delete(vector<string> &HashTable1, vector<string> &HashTable2,
	    vector<status> &StatusTable1, vector<status> &StatusTable2,
	    string x, long int M, int R) 
{
  long int pos, newpos1, newpos2;
  int i,j;

  pos = HashFn1(x, M);
  i = 0;j=0;
  
  while (i < M)
    {
      newpos1 = (pos + i*i) % M;

      if ((StatusTable1[newpos1] == ACTIVE) &&
	  (HashTable1[newpos1] == x))
	{
	  HashTable1[newpos1] = -1;
	  StatusTable1[newpos1] = DELETED;
	  cout<<newpos1<<" ";

	  break;
	}
      else
	{
	  i++;
	//   cout << "i: " << i << endl;
	}
    }

  if (i == M)
    { cout<<-1<<" ";
    }


while (j < M)
    {
      newpos2 = (pos + j*HashFn2(x,R)) % M;

      if ((StatusTable2[newpos2] == ACTIVE) &&
	  (HashTable2[newpos2] == x))
	{
	  HashTable2[newpos2] = -1;
	  StatusTable2[newpos2] = DELETED;
	  cout<<newpos2<<endl;

	  break;
	}
      else
	{
	  j++;
	//   cout << "i: " << i << endl;
	}
    }

  if (j == M)
    {  cout<<-1<<endl;
      return;
    }

      
}

void HT_search(vector<string> &HashTable1, vector<status> &StatusTable1,
               vector<string> &HashTable2, vector<status> &StatusTable2,
               string x,int M, int R)
{
    long int pos, newpos1, newpos2;
  int i,j;

  pos = HashFn1(x, M);
  i = 0;j=0;
  
  while (i < M)
    {
      newpos1 = (pos + i*i) % M;

      if ((StatusTable1[newpos1] == ACTIVE) &&
	  (HashTable1[newpos1] == x))
	{
	  cout<<newpos1<<" ";

	  break;
	}
      else
	{
	  i++;
	//   cout << "i: " << i << endl;
	}
    }

  if (i == M)
    { cout<<-1<<" ";
    }


while (j < M)
    {
      newpos2 = (pos + j*HashFn2(x,R)) % M;

      if ((StatusTable2[newpos2] == ACTIVE) &&
	  (HashTable2[newpos2] == x))
	{
	  cout<< newpos2 <<endl;

	  break;
	}
      else
	{
	  j++;
	  
	}
    }

  if (j == M)
    {
      cout<<-1<<endl;
    }
  
}
// Add HT_search to locate key x in the HT and return true or false
// (present or absent)  
// Ideally, one would return the corresponding value in the key-value pair.
// bool HT_search ....

//Print contents
void HT_print(vector<string> &HashTable1,
	      vector<status> &StatusTable1)
{
  for (int i = 0; i < HashTable1.size(); i++)
    {
      if (StatusTable1[i] == ACTIVE)
	cout << i << " " <<
	  HashTable1[i] << endl;
    }
  
}


int main()
{
  
  long int n, M, R;

  vector<string> HashTable1;
  vector<status> StatusTable1;

  vector<string> HashTable2;
  vector<status> StatusTable2;

//   cout << "Enter n M: ";
  
  cin >> M;
  cin >> R;
  HashTable1.resize(M, "");
  StatusTable1.resize(M, EMPTY);

  HashTable2.resize(M, "");
  StatusTable2.resize(M, EMPTY);

 
 while(1){
    string ins;
    cin>>ins;
 
    if(ins=="I"){
        string c;
        cin>>c;
        //cout<<endl;
        HT_insert( HashTable1, HashTable2, StatusTable1, StatusTable2, c,M,R);
    }
    if(ins=="D"){
        string c;
        cin>>c;
        //cout<<endl;
        HT_delete( HashTable1, HashTable2, StatusTable1, StatusTable2, c,M,R);
    }
    if(ins=="S"){
        string c;
        cin>>c;
        //cout<<endl;
        HT_search( HashTable1, StatusTable1, HashTable2, StatusTable2, c,M,R);
    }
    if(ins=="P"){
        int x;
        cin>>x;
        
        if(x==0){
            HT_print(HashTable1,StatusTable1);
        }
        else{
            HT_print(HashTable2,StatusTable2);
        }
    }
    if(ins=="G"){
        string c;
        cin>>c;
        //cout<<endl;
        return 0;
    }
 }

 
}
