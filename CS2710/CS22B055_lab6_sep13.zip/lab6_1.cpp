#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

class node {
    public:
    char c;
    node* next;

    node(char s){
        c = s;
        next = NULL;

    }
};

class sstack{
    public:
    node* top;

    sstack(){
        top = NULL;
    }

    void push(char s){

    if(top== NULL){
    node* temp = new node(s);
    temp->next = top;
    top = temp;
    top->next =NULL;


    }
    node* temp = new node(s);
    temp->next = top;
    top = temp;

    
    }

    void pop(){
        node* temp;

        if(top == NULL){
            return;
        }
        else{
            temp = top;
            top = top->next;

            if(temp==NULL)top = NULL;
            delete temp;
        }
    }

    char return_top(){
        node* temp = top;
        return temp->c;
        
    }  

   
};
    



int main(){
    int n;
    cin>>n;
   

    while(n--){
       bool flag = true;
       sstack st1;
       sstack st2;
       string str;
       cin>>str;
       
       for(int i=0;i<str.length();i++){
             st1.push(str[i]);
             st2.push(str[str.length() - 1 - i]);

       }
    //    st1.print();
    //    st2.print();

       


       for(int i = 0;i<str.length();i++){
           if(st1.return_top() != st2.return_top()){
            flag = false;
            break;
           }
           else{
            st1.pop();
            st2.pop();
           }
       }
        if(flag){
            cout<<1<<endl;
        }
        else{
            cout<<0<<endl;
        }
              
    }

    }

