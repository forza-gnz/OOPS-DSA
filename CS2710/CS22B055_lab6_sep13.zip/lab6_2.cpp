#include<bits/stdc++.h>
using namespace std;

class qnode{
public:
    int pid;
    int exectime;
    qnode* next;
 
  public:
  qnode(int i,int j){
    i=-1;
    j=-1;
    pid = i;
    exectime = j;
    next = NULL;
  }

  void ii(){
    cout<<pid<<" "<<exectime<<endl;
  }

  friend class QQueue;
};

class QQueue{

    public:
    qnode* first;
    qnode* last;
    int len;

    QQueue(){
        first = last = NULL;
        len = 0;
    }

    bool isempty(){
        return (first = NULL);
    }
    
    bool isfull(){
        return (last = NULL);
    }
    
    int return_pid_first(){
        return first->pid;
    }
    
    int return_exectime_first(){
        return first->exectime;
    }

    void enqueue(int x,int y){
        len++;
        qnode* temp = new qnode(x,y);

        if(last==NULL){
            first = last = temp;
            return;
        }

        last->next = temp;
        last = temp;

    }
    
    void dequeue(){
        
        if(first == NULL) return;

        qnode* temp = first;
        first = first->next;
        len--;

        if(first == NULL){
            last = NULL;
        }

        delete (temp);
    }

    int exectime_first(){
        return first->exectime;
    }
    
    void deque_not_remove(int x){
        if(first == NULL) return;

        qnode* temp = first;
        first = first->next;

        if(first == NULL){
            last = NULL;
        }

        temp->exectime -= x;
        last->next = temp;
        temp->next = NULL;
    }

    void pprint(){
        qnode* temp = first;
        while(temp!=NULL){
            cout<<temp->pid<<" "<<temp->exectime<<endl;
            temp=temp->next;
        }
    }

};       

signed main(){
    int q;
    cin>>q;
    QQueue list;


    
  while(1){
    string str;
    cin>>str;
    
    if(str=="I"){
        int r;
        int t;
        cin>>r;
        cin>>t;

        list.enqueue(r,t);
    }

    else if(str=="D"){
        if(list.exectime_first()<=0){
            list.dequeue();
        }
        else{
            list.deque_not_remove(q);
        }
    }

    else if(str=="A"){
       list.pprint();
    }

    else if(str=="END"){
        break;
    }
}

}








