// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2710 Lab 7
// Date: Oct. 4, 2023, 2pm
// Question No. 1 
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.




#include<bits/stdc++.h>
using namespace std;
#define debug cout<<"debug"<<endl;

class Elem {
    private:

    string str;
    uint lonum;
    Elem* left;
    Elem* right;
    Elem* parent;

    public:

    Elem(){
        str = "";
        lonum = 0;
        left = NULL;
        right = NULL;
        parent = NULL;
    }
    Elem(string s, int x){
        str =s;
        lonum =x;
        left = NULL;
        right = NULL;
        parent = NULL;
    }

    friend class BinaryTree;
};

class BinaryTree{
    private:
    Elem* root;

    public:

    BinaryTree(){
        root = NULL;
    }

    BinaryTree(Elem* E){
        root = E;
    }

    bool empty(){
        if(root == NULL) return true;
        else return false;
    }


    void Insert_Elem_lo(string s,int x){
        Elem* E = new Elem(s,x);
        
        if(root == NULL){
            
            root = E;
            return;
        }

        queue<Elem*> lvlorder;
        lvlorder.push(root);

        while(!lvlorder.empty()){
            Elem* temp = lvlorder.front();
            lvlorder.pop();
            //cout<<temp->str<<endl;
            if(temp->left != NULL) lvlorder.push(temp->left);

            else if(temp->left == NULL){
                temp->left = E;
                return;
            }

            if(temp->right != NULL) lvlorder.push(temp->right);

            else{
                temp->right = E;
                return;
            }
            //cout<<temp->str;
            
        }
    }

//      void PreOrderTrav()
//   {
//     PreOrderTravHelp(root);
//   }
      
//   Elem* PreOrderTravHelp(Elem * , string s)
//   {
//     if (root == nullptr) return;
//     if(root->str == s)
//     PreOrderTravHelp(root->left);
//     PreOrderTravHelp(root->right);
//   }

    Elem* Locate(string s){
        // debug;
        queue <Elem*> q;
        q.push(root);

        while(q.empty() == false){
            Elem* temp = q.front();
            // cout<<temp->str<<endl;
            if(temp->str == s){
                return temp;
            }
            q.pop();

            if(temp->left != NULL) q.push(temp->left);
            if(temp->right != NULL) q.push(temp->right);
        }

        return NULL;
        
    }

    uint LCA(string s1,string s2){
       Elem* temp1 = Locate(s1);
       Elem* temp2 = Locate(s2);

       if(temp1 == temp2){
        return temp1->lonum;
       }

       vector<Elem*> v1;
       vector<Elem*> v2;

       while(temp1!=root){
        v1.push_back(temp1->parent);
       }

       while(temp2!=root){
        v2.push_back(temp2->parent);
       }

       for(int i = 0; i< v1.size() ; i++){
         for(int j=0;j<v2.size() ; j++){
            if(v1[i]->str == v2[j]->str){
                return v1[i]->lonum; 
            }
         }
          
       }
    }
    
};

int main(){
    int n;
    cin>>n;
    // int hgt = 0;

    // for(int i=0;i<32;i++){
    //     if((n>>i)&1){
    //         hgt = i+1;
    //     }
    // }
    // cout<<hgt<<endl;

    BinaryTree BT;
    
    for(int i=0;i<n;i++){
        string s;
        cin>>s;

        BT.Insert_Elem_lo(s,i+1);
    }
    // string str;
    // cin>>str;
    // cout<<BT.Locate(str)<<endl;


    int q;
    cin>>q;

    for(int i=0;i<q;i++){
        string str1,str2;
        cin>>str1>>str2;

        cout<<BT.LCA(str1,str2)<<endl;
    }
}