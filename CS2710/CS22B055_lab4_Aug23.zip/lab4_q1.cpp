#include<bits/stdc++.h>
using namespace std;

class node{
    public:
    int data;
    node* next;
    
    public:
    node(int val){
        data =val;
        next =NULL;
    }
};

class llist{
    private:
    
    node* head;
    int size =0;


    public: 
    llist(){
       head  =NULL;
       size =0;
    }

    void insert_at_end(int val){
    
    node* n = new node(val);
    size++;
    
    if(head == NULL){
     
        head = n;
        return;
    }
   
    node* temp;
    temp = head;

    while(temp->next!= NULL){
        temp = temp->next;
    }
    temp->next = n;
    }

    void printk(int k){
        node* temp  = head;
        k--;
        while(k--){
            temp = temp->next;
        }
        cout<<temp->data<<" ";
    }

    int getsize(){
        return size;
    }

    void reorder(int k){

        if(k==size){
            return;

        }
        if(k==1){
            node* temp =head;
            node* current  = temp->next;

            while(temp->next!=NULL){
                temp = temp->next;

            }
            temp->next = head;
            head->next = NULL;
            head = current;
            return;
        }
        node* temp = head;
        for(int i = 1; i < k-1 ;i++){
             temp = temp->next;
         }

         node* current = temp->next;
         temp->next = current->next;

         while(temp->next !=NULL){
            temp =temp->next;
         }
         temp->next = current;
         current->next =NULL;
        
        // node* prev = head;
        // node* temp = head;;
        // node* temp1 = head;

        // while(temp1->next != NULL){
        //         temp1= temp1->next;
        //     }

        // if(k==1){
        //     head->next=NULL;
        //     temp1->next = head;
        //     head = prev->next;
        // }
        // else{
        // temp = temp->next;

        // for(int i = 0 ; i < k-1 ;i++){
        //     prev = prev->next;
        //     temp = temp->next;
        // }
        
        // prev = temp->next;
        // temp = temp1->next;
        // }
    }

    void rev_list(){

        if(size!=1){
        for(int i = size-1;i>=1;i--){
            reorder(i);
        }
        }
    }

    void print_list(){
        for(int i =size;i>=1;i--){
            printk(i);
        }
    }

    };

signed main(){
    llist l;
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int x;
        cin>>x;
        l.insert_at_end(x);
    }

    // l.printk(2);

    int q;
    cin>>q;
    while(q--){
        string s;
        cin>>s;

        if(s=="P"){
            int x;
            cin>>x;
            l.printk(x);
            cout<<endl;
        }
        else if(s=="R"){
            int x;
            cin>>x;
            l.reorder(x);
        }
        else if(s=="V"){
            l.rev_list();
        }
        else if(s=="A"){
            l.print_list();
            cout<<endl;
            
        }
    }
}








