#include<bits/stdc++.h>
using namespace std;

signed main(){
    int n;
    cin>>n;
    int m1[n][n];
    int m2[n][n];
    int m3[n][n];

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            m3[i][j] = 0;
        }
    }

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>>m1[i][j];
        }
    }

     for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>>m2[i][j];
        }
    }

    for(int i =0;i<n;i++){
        for(int j =0;j<n;j++){
            for(int k =0;k<n;k++){
                m3[i][j] += m1[i][k]*m2[k][j];
            }
        }
    }

    int m,l;
    cin>>m>>l;

    cout<<m3[m][l]<<endl;

}