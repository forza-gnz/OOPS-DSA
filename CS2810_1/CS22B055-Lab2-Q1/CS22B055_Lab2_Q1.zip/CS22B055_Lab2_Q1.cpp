#include <iostream>
#include <cassert>
#include "CS22B055_Lab2_DLL.cpp"
using namespace std;


class ComplexNum{
    private:
    double real;
    double imag;

    public:
    
    ComplexNum(){ //constructors
        real = 0;
        imag = 0;
    }

    ComplexNum(double a){ //construct
        real = a;
        imag = 0;
    }

    ComplexNum(double a, double b){ //construct
        real = a;
        imag = b;
    }

    ComplexNum(const ComplexNum& C1){ //consturct
        real = C1.real;
        imag = C1.imag;
    }

    ComplexNum operator+ (ComplexNum C2){
        ComplexNum C3;
        C3.real = real + C2.real;
        C3.imag = imag + C2.imag;

        return C3;
    }

    ComplexNum operator- (ComplexNum C2){
        ComplexNum C3;
        C3.real = real - C2.real;
        C3.imag = imag - C2.imag;

        return C3;
    }

    ComplexNum operator*(ComplexNum C2){
        ComplexNum C3;
        C3.real = real*(C2.real) - imag*(C2.imag);
        C3.imag = C2.imag*real + C2.real*imag;

        return C3;
    }

    ComplexNum operator/ (ComplexNum C2){
        double a1 = real;
        double b1 = imag;
        double a2 = C2.real;
        double b2 = C2.imag;
        
        if(C2.real == 0 && C2.imag == 0){
            ComplexNum C3(1,1);
            return C3;
        }

        else{
            ComplexNum C3;
            C3.real = ((a1*a2 + b1*b2)/(a2*a2 + b2*b2));
            C3.imag = ((b1*a2 - a1*b2)/(a2*a2 + b2*b2));
            return C3;
        }
    }

    int rreal(){ // to get the floor value 
        return real;
    }
    int rimag(){ // to get the floor value
        return imag;
    }

    friend ostream& operator<< ( ostream& os, const ComplexNum C1){
       os << C1.real << " " << C1.imag;
       return os;
    }
    // standrad Code

    bool operator<(ComplexNum C2){
        if(real < C2.real || (real==C2.real && imag<C2.imag) ){
            return true;
            
        }
        else{
            return false;
        }
    }
};

int main(){

    int type;
    cin>>type;
    if(type == 1){

       DLL<int> List1;
       int n;
       cin>>n;

       for(int i=0;i<n;i++){
        int x;
        cin>>x;
        List1.InsertNode(x);
       }
       while(1){
       string str;
       cin>> str;

       if(str == "I"){
        int i;
        cin>>i;
        List1.InsertNode(i);
       }

       else if(str == "U"){
        int k,i;
        cin>>k>>i;

        if ((k >= 0) && (k < List1.Length()))
            List1.updateKpos(k,i);
        else
           cout<<"OOR"<<endl;
  
       }

       else if(str=="D"){
         List1.DeleteMax();
       }

       else if(str== "S"){
        cout<< List1.SumAll()<<endl;
       }

       else if(str== "L"){
        cout<< List1.Length() << endl;
       }

       else if(str=="P"){
        List1.printList();
        cout<<endl;
       }

       else{
        break;
       }

       }
       
        }

    if(type == 2){

       DLL<double> List1;
       int n;
       cin>>n;

       for(int i=0;i<n;i++){
        double x;
        cin>>x;
        List1.InsertNode(x);
       }
       while(1){
       string str;
       cin>> str;

       if(str == "I"){
        double i;
        cin>>i;
        List1.InsertNode(i);
       }

       else if(str == "U"){
        int k;
        double i;
        cin>>k>>i;

        if ((k >= 0) && (k < List1.Length()))
            List1.updateKpos(k,i);
        else
           cout<<"OOR"<<endl;
  
       }

       else if(str=="D"){
         List1.DeleteMax();
       }

       else if(str== "S"){
        cout<< List1.SumAll()<<endl;
       }

       else if(str== "L"){
        cout<< List1.Length() << endl;
       }

       else if(str=="P"){
        List1.printList();
        cout<<endl;
       }

       else{
        break;
       }

       }
    }
       if(type==3){

         DLL<ComplexNum> List1;
       int n;
       cin>>n;

       for(int i=0;i<n;i++){
        double x,y;
        cin>>x>>y;
        List1.InsertNode(ComplexNum(x,y));
       }
       while(1){
       string str;
       cin>> str;

       if(str == "I"){
        double i,j;
        cin>>i>>j;

        List1.InsertNode(ComplexNum(i,j));
       }

       else if(str == "U"){
        int k;
        double i,j;
        cin>>k>>i>>j;

        if ((k >= 0) && (k < List1.Length()))
            List1.updateKpos(k,ComplexNum(i,j));
        else
           cout<<"OOR"<<endl;
  
       }

       else if(str=="D"){
         List1.DeleteMax();
       }

       else if(str== "S"){
        cout<< List1.SumAll()<<endl;
       }

       else if(str== "L"){
        cout<< List1.Length() << endl;
       }

       else if(str=="P"){
        List1.printList();
        cout<<endl;
       }

       else{
        break;
       }

       }
       
    }

   

}

       

    

