
// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2810 Lab Number: 2
// Date:30 jan, 2024, 2pm
// Question No. 1 (
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate

#include <iostream>
#include <cassert>
#include<climits>
#include "CS22B055_Lab2_DLL.h"
using namespace std;

template <typename T2>
DLL<T2>::DLL()
  {first = NULL;
    last = NULL;
    head = NULL;
    tail = NULL;
    len = 0;
    

  }

template <typename T2>
void DLL<T2>::DeleteMax()
{
  // cout<<"delete max Entered"<<endl;
  Node<T2> *temp = first;
  Node<T2> *temp1  =first;

  if(len == 0) return;

  // cout<<first->data<<endl;
  // cout<<temp->data<<endl;
  T2 maxa = first->data;
  int i=0;
  while(temp!=tail){
    
    // cout<<"i="<<i++<<endl;
    
    if(maxa < temp->data){
      //  if(i==4) cout<<"SSSSS"<<endl;
      maxa = temp->data;
      temp1 = temp;
    }
    //  if(i==4) break;
    temp = temp->next;

    
  }
  
  // cout<<temp->data<<endl;

  if(temp1==first){
    
    first = first->next;
    // cout<<"123"<<endl;
    // head->next = first;
    // cout<<1234<<endl;
    first->prev = head;
  }
  else if(temp1==last){
      last = last->prev;
       last->next = tail;
      // tail->prev = last;
  }
  else {
   Node<T2> *pr = temp1->prev;
   Node<T2> *nx = temp1->next;

   pr->next =nx;
   nx->prev = pr;

  }

  delete temp1;
  len--;
  return;

}
template <typename T2>
T2 DLL<T2>:: SumAll(){
    T2 sum = 0;
    Node<T2> *temp = first;
    if(len == 0) return 0;
    else{
        while(temp->next!=NULL){
            sum =  sum + temp->data;
            temp = temp->next;
        }
        sum = sum + temp->data;
        return sum;
    }
}



// Indices run from 1 to n.
//  SLL[k] = j;
template <typename T2>
void DLL<T2>::updateKpos (int k, T2 j)
{
  Node<T2> *temp = this->first; // Node *temp = first;

  assert((k >= 1) && (k <= len));

  for (int i = 1; i < k; i++)
    {
      temp = temp -> next;
    }

  temp -> data = j;
}

// Create a Node with data item as d; insert this Node into the end of
// this object Linked List.

template <typename T2>
void DLL<T2>::InsertNode (T2 d)
{

  Node<T2> *ToAddNode = new Node<T2>(d);
  Node<T2> *temp;
  
  //  assert(ToAddNode->data == d);

  if (first == nullptr)
    {
      first = last = ToAddNode;
      len++;
      return;
    }
  else
    {
      temp = first;
      while (temp->next != nullptr)
	      temp = temp->next;

      temp->next = ToAddNode;
      ToAddNode->prev = temp;
      last = ToAddNode;
      len++;
    }
}

template <typename T2>
uint DLL<T2>::Length()
{
  return len;
}

template <typename T2>
void DLL<T2>::printList()
{
  Node<T2> *temp = first;

  while (temp != nullptr)
    {
      temp->Print();
      temp = temp -> next;
    }

}