#include <iostream>
#include <cassert>
#include "CS22B055_Lab2_Node.h"

using namespace std;

template <typename T1>
Node<T1>::Node()
{
  next = nullptr;
  prev = nullptr;
}

template <typename T1>
Node<T1>::Node (T1 d): data(d)
{
  next = nullptr;
  prev = nullptr;
}

template <typename T1>
void Node<T1>::Print()
{
  cout << "Node value: " << data << endl;
}
