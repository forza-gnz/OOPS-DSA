#include <iostream>
#include <cassert>
using namespace std;

#pragma once
template <typename T2> class DLL; // Forward definition for compiler.

template <typename T1>

class Node {
public:
T1 data;
Node<T1> *next;
Node<T1> *prev;
Node()
{
  data = 0;
  next = NULL;
  prev = NULL;
}
Node (T1 d): data(d)
{
   next = NULL;
   prev = NULL;
}
// Any other constructors needed
void Print()
{
cout << data << " ";
}
friend class DLL<T1>;
};

// #include "lab2_Node.cpp"


