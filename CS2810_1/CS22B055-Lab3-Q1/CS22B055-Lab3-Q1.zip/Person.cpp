#include <iostream>
#include <cassert>
#include "Person.h"

Person::Person(unsigned int sad, string naam){
    sadhar = sad;
    name = naam;
}

string Person::GetName(){
    return name;
}

uint Person:: GetId(){
    return sadhar;
}

void Person::Print(){
    cout<<sadhar<<" "<<name<<endl;
}


