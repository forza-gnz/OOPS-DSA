#include<iostream>
#include"Course.h"
#include"Faculty.h"
#include"Person.h"
#include"Student.h"

int main(){
    int F,S;
    cin>>F>>S;
    vector<Faculty> facs;
    for(int i=0;i<F;i++){
        int id;cin>>id;
        vector<Course> CrsF;
        string name;
        cin>>name;
        int N;
        cin>>N;
        for(int j=0;j<N;j++){
            int x;
            cin>>x;
            int t=0;
            for(int k=0;k<CrsF.size();k++){
                if(CrsF[i].GetCid()==x){
                    t=1;
                    break;
                }
                else t=0;
            }

            if(t==0){
                CrsF.push_back(Course(x,0));
            }
            
        }
        

        int J,C;
        cin>>J>>C;

        facs.push_back(Faculty(id,name,CrsF, J, C));
    }

    vector<Student> stud;

    for(int i=0;i<S;i++){
        int id;
        cin>>id;
        string name;
        cin>>name;
        int N;
        cin>>N;
        
        vector<Course> CrsS;
        for(int j=0;j<N;j++){
           int idd,gr;
           cin>>idd>>gr;
            int t=0;
            for(int k=0;k<CrsS.size();k++){
                if(CrsS[i].GetCid()==idd){
                    t=1;
                    break;
                }
                else t=0;
            }

            if(t==0){
                CrsS.push_back(Course(idd,gr));
            }
           
        //    if(CrsS.find(Course(idd,gr))){
        //    CrsS.push_back((Course(idd,gr)));
        }
        

        int fid;
        cin>>fid;
        stud.push_back(Student(id,name,CrsS,fid));
    }

    string s;
    cin>>s;

    while(1){
        if(s=="P"){
            int sid;
            cin>>sid;
            for(int i=0;i<S;i++){
                if(sid==stud[i].GetId()){
                    stud[i].Print();
                }
            }
        }

        if(s=="K"){
            int fid;
            cin>>fid;
            for(int i=0;i<F;i++){
                if(fid==facs[i].GetId()){
                    facs[i].Print();
                }
            }
            
        }
        
        if(s=="H"){
            int mina = 0;
            int j=-1;
            for(int i = F-1; i >= 0; i--){
                if(facs[i].GetJournals()>=mina){
                    j=i;
                }
            }

            if(j!=-1){
            facs[j].Print();
            }

        }

        if(s=="M"){
            int fid;cin>>fid;
            int j=-1;
            for(int i=0;i<F;i++){
                if(fid==facs[i].GetId()){
                    j = i;
                }
            }
            int cnt_s=0;
            if(j!=-1){
                for(int i=0;i<S;i++){
                    if(stud[i].GetFacad()==fid){
                        cnt_s++;
                    }
                }
            }
            cout<<cnt_s<<endl;
        }

        if(s=="X"){
            break;
        }
        cin>>s;
    }
    }

    
