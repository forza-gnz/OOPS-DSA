#include <iostream>
#include <iomanip>
#include <vector>
#include <string>

using namespace std;

#pragma once
class Person
{

 private:

  unsigned int sadhar;
  string name;

 public:
  Person();
  
  Person(unsigned int sad, string naam); // assigned respectively

  string GetName();

  unsigned int GetId();
  
  void Print(); // Prints id and name separated by a blank space on
                  // one line.
};
