#include <iostream>
#include <cassert>
#include "Faculty.h"
#include"Person.h"

Faculty::Faculty(unsigned int sad, string naam, vector<Course> C, unsigned int jo, unsigned int co) : Person(sad,naam){
    // for(int i = 0; i<C.size();i++){
        CoursesTaught = C;
    // }

    journals = jo;
    confs = co;
}

uint Faculty::GetJournals(){
    return journals;
}

uint Faculty::GetConfs(){
    return confs;
}

vector<Course> Faculty::GetCourses(){
    return CoursesTaught;
}

void Faculty:: Print(){
    cout<<GetId()<<" "<< GetName()<<" "<< journals<<" "<< confs<<endl;
}

