#include <iostream>
#include <cassert>
#include "Color.h"

Color::Color(string s){
    s = "none";
}

void Color::setColor(string s){
      color = s;
}

string Color::getColor(){
    return color; 
}




