#include<iostream>
#include"Square.h"
#include"Shape.h"

Square::Square(int id1, stype sht1, unsigned int s1):Shape(id1,sht1){
    side = s1;
    
}

double Square::area(){
    double ar = side*side;
    return ar;
}

double Square::perimeter(){
    return 4*side;
}

double Square::diagonal(){
    return sqrt(2)*side;
}
