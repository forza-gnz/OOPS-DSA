#include<iostream>
#include"Shape.h"

int Shape::getId(){
    return id;
}

stype Shape::getType(){
    return shape_type;
}

string Shape::getShapeName(){
    string s = ShapeNames[shape_type];
    s[0]= toupper(s[0]);
    return s;
}
