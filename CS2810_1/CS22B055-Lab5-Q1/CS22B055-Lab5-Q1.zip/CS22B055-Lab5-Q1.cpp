#include "Shape.h"
#include "Triangle.h"
#include "Color.h"
#include "Square.h"
#include "Hexagon.h"
#include "Circle.h"
#include<iostream>
using namespace std;

// Modify this to print color value *AFTER* Shape string if
// the Shape is a Circle.
void display(Shape *s)
{
  // cout << s->getShapeName() << endl;
   if(s->getShapeName() == "Circle"){
  cout << "Id: " << s->getId()<<
    " Shape: " << s->getShapeName() <<
    " Color: " << "none" <<
    " Area: " << (int) s->area() <<
    " Perimeter: " << (int) s->perimeter() <<
    " Diagonal: " << (int) s->diagonal() << endl;
}
else{
    cout << "Id: " << s->getId()<<
    " Shape: " << s->getShapeName() <<
    // " Color: " << none <<
    " Area: " << (int) s->area() <<
    " Perimeter: " << (int) s->perimeter() <<
    " Diagonal: " << (int) s->diagonal() << endl;

}
}

int main()
{
  vector<Shape *> AllShapes;
  string str1;
  int id1, side1;
  id1 = 0;
  cin>>str1;

  while(1){
    if(str1=="triangle"){
      cin>>side1;
      AllShapes.push_back((new Triangle(id1,triangle,side1)));
      id1++;
    }

    else if(str1=="square"){
      cin>>side1;
      AllShapes.push_back((new Square(id1,square,side1)));
      id1++;
    }

    else if(str1=="hexagon"){
      cin>>side1;
      AllShapes.push_back((new Hexagon(id1,hexagon,side1)));
      id1++;
    }

    else if(str1=="circle"){
      cin>>side1;
      AllShapes.push_back((new Circle(id1,circle,side1)));
      id1++;
    }

    else if(str1=="END"){
      int x;cin>>x;
      break;
    }
    else{
      //ignore;
    }
    // cout<<AllShapes.size()<<endl;
    cin>>str1;
    
   
  }

  string str2;
  cin>>str2;
  int id2;

  while(1){
    if(str2=="P"){
      cin>>id2;
      // cout<<id2<<endl;
      if(id2 >= AllShapes.size()){
        cout<<-1<<endl;
      }
      else{
        // cout<<id2<<endl;
        // cout<<"enter"<<endl;
        display(AllShapes[id2]);
      }
    }

    if(str2=="A"){
      string x;   
      cin>>x;
      x[0]=toupper(x[0]);

      if(x=="Triangle"||
      x=="Square"||
      x=="Circle"||
      x=="Hexagon"){
      int j=0;
      double maxa = 0;
      for(int i=0;i<AllShapes.size();i++){
        if(AllShapes[i]->getShapeName()==x){
          if(AllShapes[i]->area() > maxa){
            maxa = AllShapes[i]->area();
            j=i;
          }
        }
      }
      
      display(AllShapes[j]);
    }

    else{
      cout<<-1<<endl;
    }
    }
    

    if(str2=="H"){
      int j=0;
      double maxa = 0;

      if(AllShapes.size()!=0){
      for(int i=0;i<AllShapes.size();i++){
        if(AllShapes[i]->area() > maxa){
          j = i;
        }
      }
      display(AllShapes[j]);
      }

      else{
          cout<<-1<<endl;
      }
    }

    if(str2=="X"){
      break;
    }

    cin>>str2;

 }


}
