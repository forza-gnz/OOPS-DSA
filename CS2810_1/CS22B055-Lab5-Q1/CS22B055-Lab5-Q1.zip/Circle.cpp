#include<iostream>
#include"Color.h"
#include"Shape.h"
#include"Circle.h"


Circle::Circle(int id1, stype sht1, unsigned int s1):Shape(id1,sht1),Color(){
    rad = s1;
    
}


double Circle::area(){
    return M_PI*rad*rad;
}

double Circle::perimeter(){
    return 2*M_PI*rad;
}

double Circle::diagonal(){
    return 2*rad;
}
