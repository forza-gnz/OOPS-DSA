#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include "Shape.h"
#include "Color.h"

using namespace std;

#pragma once

class Circle: public Shape, public Color
{
 private:
  unsigned int rad;

 public:
  Circle(int id1, stype sht1, unsigned int s1 = 0);

  // Must declare the methods here to indicate that
  // the virtual functions in base class will be implemented in this class.
  double area();
  double perimeter();
  double diagonal();
};
// DO NOT INCLUDE any Triangle.cpp file  etc.
