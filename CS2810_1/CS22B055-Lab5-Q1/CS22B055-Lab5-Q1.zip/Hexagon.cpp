#include<iostream>
#include"Hexagon.h"
#include"Shape.h"


Hexagon::Hexagon(int id1, stype sht1, unsigned int s1):Shape(id1,sht1){
    side = s1;
    
}


double Hexagon::area(){
    double ar = 6*(sqrt(3)/4)*side*side;
    return ar;
}

double Hexagon::perimeter(){
    return 6*side;
}

double Hexagon::diagonal(){
    return 2*side;
}
