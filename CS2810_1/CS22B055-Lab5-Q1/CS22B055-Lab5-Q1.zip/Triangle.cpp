#include<iostream>
#include"Triangle.h"
#include"Shape.h"

Triangle::Triangle(int id1, stype sht1, unsigned int s1):Shape(id1,sht1){
    side = s1;
    
}


double Triangle::area(){
    double ar = (sqrt(3)/4)*side*side;
    return ar;
}

double Triangle::perimeter(){
    return 3*side;
}

double Triangle::diagonal(){
    return -1.0;
}
