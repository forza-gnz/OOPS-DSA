#include<iostream>
using namespace std;

#include"RegFaculty.h"

RegFaculty::RegFaculty(unsigned int sad, string naam, persontype p,
	     vector<Course> C, unsigned int jo, unsigned int co,
	     unsigned int S[], unsigned int nadv):Faculty(sad,naam,p,C,jo,co){
            advisees = S;
            numadv = nadv;

}

bool RegFaculty::isAdvisor(uint sid){
    bool flag= 0;
    for(int i = 0;i<numadv;i++){
        if(sid == advisees[i]){
            flag = true;
            break;
        }
    }
    return flag;
}

uint RegFaculty::NumAdvisees(){
    return numadv;
}

void RegFaculty:: Print(){
    cout<<GetId()<<" "<< GetName()<<" "<< GetJournals()<<" "<<GetConfs()<<endl;
}