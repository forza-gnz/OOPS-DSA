#include<bits/stdc++.h>
#include "Course.h"
#include "Person.h"
#include "Faculty.h"
#include "RegFaculty.h"
#include "VisFaculty.h"
#include "Student.h"


// Reg. Faculty: 1000 - 1999
// Vis. Faculty: 2000 - 2999
// Students: 3000 - 9999
const unsigned int PERSONS = 1000;

int main()
{
  vector<Person *> AllPersons;
  
  
//   unsigned int *S;

  string Q;
  uint id;
  cin>>id;
  while(id!=-1){
	if( id>=1000 && id<2000){
		vector<Course> Taught;
		string name;
		cin>>name;
		int N;cin>>N;

		for(int i=0;i<N;i++){
			int x;
			cin>>x;
			Taught.push_back(Course(x,0));
		}
		uint J,C;
		cin>>J>>C;
		int NA;
		cin>>NA;
		uint *S = new uint[NA];

        for(int i=0;i<NA;i++){
			cin>>S[i];
		}
 
		 AllPersons.push_back((RegFaculty *) new
			 RegFaculty(id, name, rfa, Taught,
				    J, C, S, NA));
	
	}
	if(id>=2000 && id<3000){
		string name;
		cin>>name;
		vector<Course> taught1;
		int N; cin>>N;

		for(int i=0;i<N;i++){
			int x; cin>>x;
			taught1.push_back(Course(x,0));
		}

		uint J,C,hid;
		cin>>J>>C>>hid;

		AllPersons.push_back((VisFaculty *) new
			VisFaculty(id, name, vfa, taught1,
				    J, C, hid));


	}

	if(id>=3000 && id<10000){
		// cout<<"enter"<<endl;
		string name;
		cin>>name;
		uint C;
		cin>>C;
		vector<Course> Taken;

		for(int i=0;i<C;i++){
			int x,gr;
			cin>>x>>gr;
			Taken.push_back(Course(x,gr));
		}

		int fid;
		cin>>fid;

		AllPersons.push_back((Student *) new
			Student(id, name, cst, Taken,
				    fid));
		
	}
	cin>>id;
  }


    // Example way to add a Reg. Faculty object pointer to AllPersons
    // AllPersons.push_back((RegFaculty *) new
	// 		 RegFaculty(id, name, p, Taught,
	// 			    journals, confs, S, NA)); 
  
    cin >> Q;
    while (Q != "X")
      {
		
	
		if(Q=="H"){
	    // Print name of host faculty given vid
	  
		uint idd;
		cin>> idd;
		uint hidd=0;
		// cout<<AllPersons.size()<<endl;

		for(int i=0;i<AllPersons.size();i++){
			// cout<<i<<" "<<AllPersons[i]->GetPType()<<endl;
				if(AllPersons[i]->GetPType() == vfa){
					// cout<<"enter"<<endl;
					
					if(idd == AllPersons[i]->GetId()){
						// cout<<"ent"<<endl;
					VisFaculty *visaf = (VisFaculty *) AllPersons[i];
					hidd = visaf->GetHost();
					}
				}
			
		}
        //  cout<<123<<endl;
		//  cout<<hidd<<endl;
		for(int i=0;i<AllPersons.size();i++){
			if(hidd == AllPersons[i]->GetId()){
				RegFaculty *Regaf = (RegFaculty *) AllPersons[i];
				cout<< Regaf->GetId()<<" "<<Regaf->GetName()<<endl;
				break;
			}
		}

	   	}// End 'H' query
	    
	  if(Q=="J"){	// Student with highest CGPA
	    unsigned int maxcg;
	    unsigned int max_stud_id;

	    maxcg = 0;
		int k=0;
	    for (unsigned int j = 0; j < AllPersons.size(); j++)
	      {
		if (AllPersons[j]->GetPType() == cst)
		  { 
			
		    // Need to get a cast Pointer to Derived Class
		    // If there are other ways, you can use that too.
		    Student *stud = (Student *) AllPersons[j];

			if(stud->GetCG() > maxcg){
				k = j;
				maxcg = stud->GetCG();
			}

                       
		  } // End If
	      }	// End For
		  
	    cout << AllPersons[k]->GetId()<< endl;
	    }  	// End 'J' query

	  if(Q=="U"){	
		int sid;// Change VisFac to Reg
	    cin >> sid;
		int check =0 ;
		for (unsigned int j = 0; j < AllPersons.size(); j++)
	      {
		if (AllPersons[j]->GetPType() == rfa)
		  { 
			
		    // Need to get a cast Pointer to Derived Class
		    // If there are other ways, you can use that too.
		    RegFaculty *regf = (RegFaculty *) AllPersons[j];
			if(regf->isAdvisor(sid)){
				check =1;
				break;
			}
                       
		  } // End If
	      }	// End For
	    cout << check << endl;
		} 	// End 'U' query

	  
	
	cin >> Q;
	
      }	// End While
}

