#include <iostream>
#include <cassert>
#include "Course.h"

Course::Course(){
    cid = 0;
    gradepoint = 0;
}

Course::Course(uint id, uint grade){
    if(id<100 || id>999){
        cid = 0;
    }
    else{
        cid = id;
    }

    if(grade<4 || grade>10){
        gradepoint = 0;
    }
    else{
        gradepoint = grade;
    }
}

uint Course::GetCid(){
    return cid;
}

uint Course::GetGrade(){
    return gradepoint;
}

void Course::SetGrade(int g){
    if(g<4 || g>10){
        gradepoint = 0;
    }
    else{
        gradepoint = g;
    }
}

void Course::Print(){
    cout<< GetCid() << " "<< GetGrade()<<endl;
}


