#include <iostream>
#include <cassert>
#include "Person.h"

Person::Person(unsigned int sad, string naam, persontype p){
    sadhar = sad;
    name = naam;
    ptype = p;
}

string Person::GetName(){
    return name;
}

void Person::SetName(string naam){
    name = naam;
}

persontype Person::GetPType(){
    return ptype;
}

void Person::SetPType(persontype p){
    ptype = p;

}
uint Person:: GetId(){
    return sadhar;
}

void Person:: SetId(uint sad){
    sadhar = sad;
}

void Person::Print(){
    cout<<sadhar<<" "<<name<<endl;
}




