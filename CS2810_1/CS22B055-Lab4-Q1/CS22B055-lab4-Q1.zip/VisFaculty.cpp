#include<iostream>
using namespace std;

#include"VisFaculty.h"

VisFaculty::VisFaculty(unsigned int sad, string naam, persontype p,
	     vector<Course> C, unsigned int jo, unsigned int co,
	     unsigned int h):Faculty(sad,naam,p,C,jo,co){
            
            host = h;
}

uint VisFaculty::GetHost(){
    return host;
}

void VisFaculty:: SetHost(uint h){
    host = h;
}

void VisFaculty:: Print(){
    cout<<GetId()<<" "<< GetName()<<" "<<GetJournals()<<" "<< GetConfs()<<" "<< host <<endl;
}



