#include <iostream>
#include <cassert>
#include "Student.h"
#include "Person.h"

Student::Student(unsigned int sad, string naam,persontype p, vector<Course> C, unsigned int fid): Person(sad,naam,p){
   
   CoursesTaken = C;
    uint sum = 0;
    // for(int i=0;i<CoursesTaken.size();i++){
    //      sum += CoursesTaken[i].GetGrade();
    // }
    cgpa = sum/CoursesTaken.size();
    facad = fid;
}

vector<Course> Student::GetCourses(){
    return CoursesTaken;
}

uint Student::GetCG(){
    return cgpa;
}

uint Student:: GetFacad(){
    return facad;
}

void Student::Print(){
    cout<< GetId() <<" "<< GetName() <<" "<<cgpa<< " " << facad<<endl;
}



