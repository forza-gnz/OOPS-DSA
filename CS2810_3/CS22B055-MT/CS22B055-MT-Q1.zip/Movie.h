#include<iostream>
#include<string>
#include<vector>

#include "Artiste.h"
#include "Actor.h"
#include "Director.h"

#pragma once
class Movie {

 private:
  int mid;
  string mname;			// No Spaces; only from [A-Z][a-z]
  Director *diro;
  vector<Actor *> ActorList;
  int vasool; // Collection from theatres, OTT, etc.

  // Computed
  int cost; // Salary of Director + Salary of Actors
  int profit; // vasool - cost

 public:

  Movie()
  {
    // Fill this if needed.
  }

  // Non-default arguments at start
  Movie(Director *d1, vector<Actor *> A1, int m1 , string mname1, 
	int va){
    diro =d1;
    ActorList = A1;
    mid = m1;
    mname = mname1;
    vasool = va;
  } 

  int getMid();
  
  int getCost(){
    //Calculating the Cost and returning it 
    int sum = 0;
    sum += diro->getSalary();

    for(int i=0;i<ActorList.size();i++){ 
      // cout<<"enter"<<endl;
      sum += ActorList[i]->getSalary();
    }

    return sum;
  }

  int getProfit()
  {
    profit = vasool-getCost();
    return profit;
  }
  
  void printprofit() {
    cout << "Movie: " << mname << "; Profit: " << profit << endl;
    // cout<<vasool<<" "<<getCost()<<endl;
  }

  void display();
  // Define suitable public member functions based on queries / virtual
  // functions etc. 
  
};
