// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1 (2, etc. as appropriate)
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include<iostream>
using namespace std;
#include<cmath>

#include"Actor.h"
#include"Director.h"
#include"Artiste.h"
#include"Movie.h"

int main(){
    vector<Actor*> AllActors;
    vector<Director*> AllDirectors;
    vector<Movie*> AllMovies;

    string s;
    cin>>s;
    int ida = 0;
    int idd = 0;

    while(1){
        if(s=="actor"){
            string fn,ln;
            cin>>fn>>ln;
            int sal,nact,nhit;
            cin>>sal>>nact>>nhit;
            AllActors.push_back(new Actor(ida,fn,ln,sal,nact,nhit));
            ida++;
        }

        if(s=="director"){
            string fn,ln;
            cin>>fn>>ln;
            int sal,ndir;
            cin>>sal>>ndir;
            AllDirectors.push_back(new Director(idd,fn,ln,sal,ndir));
            idd++;
        }

        if(s=="END"){
            break;
        }
        cin>>s;
    }
    int mid=0;


    while(1){
        string x;
        cin>>x;
        if(x=="END"){
            break;
        }
        int dirid;
        cin>>dirid;
        Director *d1;

        for(int i=0;i<AllDirectors.size();i++){
            if(AllDirectors[i]->getId()==dirid){
                d1 = AllDirectors[i];//
            }
        }
        int vaso;
        cin>>vaso;

        int N;
        cin>>N;
        vector<Actor *> A1;

        for(int i=0;i<N;i++){
            int aid;
            cin>>aid;

            for(int j;j<AllActors.size();j++){
                    if(AllActors[i]->getId()==aid){
                        A1.push_back(AllActors[i]);
                    }
            }
        }

    AllMovies.push_back(new Movie(d1,A1,mid,x,vaso));

    mid++;
}

string y;

while(1){
    cin>>y;

    if(y=="X"){
        break;
    }

    if(y=="A"){
        int X;
        cin>>X;

        for(int i=0;i<AllActors.size();i++){
            if(AllActors[i]->getNhit() >= X){
                cout<<AllActors[i]->getFName()<<" "<<
                      AllActors[i]->getLName()<<endl;
            }
        }
    }

    if(y=="C"){
        int id;
        cin>>id;

        if(id>AllActors.size() || id<0){
        }
        else{
            cout<<"actor"<<" ";
            AllActors[id]->display();
        }
    }

    if(y=="D"){
        int id;
        cin>>id;

        if(id>AllDirectors.size() || id<0){
        }
        else{
            cout<<"director"<<" ";
            AllDirectors[id]->display();
        }
    }
    int maxa = 0;
    int k = 0;

    if(y=="M"){
        // cout<<"enter"<<endl;
        for(int i=0;i<AllMovies.size();i++){
            if(AllMovies[i]->getProfit() > maxa){
                k = i;
                maxa = AllMovies[i]->getProfit();
            }
        }

        AllMovies[k]->printprofit();
    }
 }
}