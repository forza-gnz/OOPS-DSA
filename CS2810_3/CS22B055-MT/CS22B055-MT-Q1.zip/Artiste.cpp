// Roll Number: CS22B055
// Name:Neeraj Bandhey
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1 (2, etc. as appropriate)
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include<iostream>
using namespace std;
#include"Artiste.h"

string Artiste::getFName(){
    return fname;
}

string Artiste::getLName(){
    return lname;
}

int Artiste::getId(){
    return id;
}

int Artiste::getSalary(){
    return salary;
}

void Artiste::setSalary(int s1){
    salary = s1;
}

void Artiste::display(){
    
}
