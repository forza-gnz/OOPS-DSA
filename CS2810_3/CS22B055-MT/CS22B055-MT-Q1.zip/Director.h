#include<iostream>
#include<string>
#include<vector>
#include"Artiste.h"

#pragma once
class Director: public Artiste{

 private:
    int n_dir;

 public:

    Director(int id1,string fname1 ,string lname1 ,int s1, int ndir);

    int getNdir();
    // int getNhit();
    void display();
    
};