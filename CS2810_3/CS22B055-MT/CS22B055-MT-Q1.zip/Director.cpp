// Roll Number: 
// Name:
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1 (2, etc. as appropriate)
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include<iostream>
using namespace std;
#include"Artiste.h"
#include"Director.h"

Director::Director(int id1,string fname1 ,string lname1 ,int s1, int ndir):Artiste(id1,fname1,lname1,s1){
    n_dir = ndir;
}

int Director::getNdir(){
    return n_dir;
}

void Director::display(){
    cout<<getId()<<" "<<getFName()<<" "<<getLName()<<" "<<getSalary()
    <<getNdir()<<endl;
}
