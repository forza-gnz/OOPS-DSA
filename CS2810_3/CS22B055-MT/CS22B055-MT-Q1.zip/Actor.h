// Roll Number: 
// Name:
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1 (2, etc. as appropriate)
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.

#include<iostream>
#include<string>
#include<vector>
#include"Artiste.h"

#pragma once
class Actor: public Artiste{

 private:
    int n_acted;
    int n_hits;

 public:

    Actor(int id1,string fname1 ,string lname1 ,int s1, int nact, int nhit);
    int getNact();
    int getNhit();
    void display();
    
};