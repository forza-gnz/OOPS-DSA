#include<iostream>
#include<string>
#include<vector>
using namespace std;

#pragma once
class Artiste{

 private:
  int id;
  string fname;
  string lname;
  int salary;
  
 public:

  Artiste(int id1 = -1, string fname1 = "", string lname1 = "", int s1 = -1)
  // default is -1, "", "", -1
    {
      id = id1;
      fname = fname1;
      lname = lname1;
      salary = s1;
    }

  string getFName();
  string getLName(); 
  int getId();
  int getSalary();
  void setSalary(int s1);
  virtual void display() = 0;
  
};
