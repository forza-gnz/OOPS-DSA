// Roll Number: CS22B055
// Name: Neeraj Bandhey
// CS2810 Midterm Exam
// Date: March 5, 2024, 2pm
// Question No. 1 (2, etc. as appropriate)
// This submission is based entirely on my efforts. I realize that
// any form of academic dishonesty with respect to the Lab assignment
// will result in
// corrective action imposed by the IIT Madras Senate.
#include<iostream>
using namespace std;
#include"Artiste.h"
#include"Actor.h"

Actor::Actor(int id1,string fname1 ,string lname1 ,int s1, int nact, int nhit):Artiste(id1,fname1,lname1,s1){
    n_acted = nact;
    n_hits =  nhit;
}

int Actor::getNact(){
    return n_acted;
}

int Actor::getNhit(){
    return n_hits;
}

void Actor::display(){
    cout<<getId()<<" "<<getFName()<<" "<<getLName()<<" "<<getSalary()<<" "
    <<getNact()<<" "<<getNhit()<<endl;
}
    